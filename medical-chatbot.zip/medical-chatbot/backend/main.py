from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import os
import openai
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise RuntimeError("Set OPENAI_API_KEY in environment or .env file")

openai.api_key = OPENAI_API_KEY

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Query(BaseModel):
    message: str

EMERGENCY_KEYWORDS = [
    "suicide", "kill myself", "need to die", "self-harm", "chest pain", "not breathing",
    "unconscious", "bleeding heavily", "severe allergic", "call 911", "emergency"
]

DANGEROUS_REQUEST_KEYWORDS = [
    "how to make", "how to inject", "how to administer dose", "dosage", "prescribe",
    "prescription", "illegal", "compound", "poison"
]

SYSTEM_PROMPT = (
    "You are a cautious, professional medical assistant that provides general health information, "
    "explains medical terms in plain language, gives first-aid guidance for non-life-threatening issues, "
    "and always encourages users to consult licensed healthcare providers for diagnosis and treatment. "
    "Never provide prescriptions, exact drug dosages, or instructions for illegal or dangerous acts. "
)

@app.post("/chat")
async def chat(query: Query, request: Request):
    text = query.message.strip().lower()

    for kw in EMERGENCY_KEYWORDS:
        if kw in text:
            return {
                "reply": (
                    "I may be wrong, but it sounds like you might be having a medical emergency. "
                    "Please call your local emergency number or go to the nearest emergency department immediately. "
                    "If you are in immediate danger, contact emergency services now."
                )
            }

    for kw in DANGEROUS_REQUEST_KEYWORDS:
        if kw in text:
            return {
                "reply": (
                    "I can’t help with instructions for prescriptions, dosages, or unsafe/illegal activities. "
                    "Please consult a licensed healthcare professional or pharmacist."
                )
            }

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": query.message}
    ]

    try:
        resp = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=messages,
            max_tokens=600,
            temperature=0.2,
        )
        answer = resp.choices[0].message["content"].strip()

        disclaimer = (
            "\n\n⚠️ This is general information only and not a replacement for professional medical care. "
            "If symptoms are severe or urgent, seek immediate medical attention."
        )

        return {"reply": answer + disclaimer}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
