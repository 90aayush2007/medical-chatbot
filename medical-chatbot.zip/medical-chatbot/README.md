# Medical Chatbot (Frontend + Backend)

This project is a minimal demo of a medical chatbot:
- Backend: FastAPI (backend/main.py) — integrates with OpenAI.
- Frontend: React + Vite (frontend/src/App.jsx).

Important: This is for informational/demo purposes only. It is NOT medical advice.
