import React, { useState } from 'react'
import { createRoot } from 'react-dom/client'

function App(){
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState([])
  const [loading, setLoading] = useState(false)

  async function send(){
    if(!input.trim()) return
    const userMsg = { role: 'user', text: input }
    setMessages(m => [...m, userMsg])
    setLoading(true)

    try{
      const res = await fetch('http://localhost:8000/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input })
      })
      const data = await res.json()
      setMessages(m => [...m, { role: 'assistant', text: data.reply }])
    }catch(err){
      setMessages(m => [...m, { role: 'assistant', text: 'Error: unable to reach server.' }])
    }finally{
      setLoading(false)
      setInput('')
    }
  }

  return (
    <div style={{ maxWidth: 720, margin: '24px auto', fontFamily: 'system-ui, sans-serif' }}>
      <h1>Medical Chatbot (Demo)</h1>
      <div style={{ border: '1px solid #ddd', padding: 12, borderRadius: 8, minHeight: 300 }}>
        {messages.length === 0 && <p style={{ color: '#666' }}>Ask a medical question (general health info only).</p>}
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 12, color: '#888' }}>{m.role === 'user' ? 'You' : 'Bot'}</div>
            <div style={{ whiteSpace: 'pre-wrap', background: m.role === 'user' ? '#eef' : '#f7f7f7', padding: 8, borderRadius: 6 }}>{m.text}</div>
          </div>
        ))}
        {loading && <div style={{ color: '#666' }}>Thinking...</div>}
      </div>

      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <input value={input} onChange={e => setInput(e.target.value)} style={{ flex: 1, padding: 10, borderRadius: 6, border: '1px solid #ccc' }} placeholder="Type your question..."/>
        <button onClick={send} disabled={loading} style={{ padding: '10px 14px', borderRadius: 6 }}>Send</button>
      </div>

      <p style={{ fontSize: 12, color: '#666', marginTop: 12 }}>
        ⚠️ This demo is for informational use only. It does not replace medical professionals.
      </p>
    </div>
  )
}

const root = createRoot(document.getElementById('root'))
root.render(<App />)

export default App
